  
  <div class="col-sm-3">
    
    <div class="panel panel-info">
      <div class="panel-heading">
        <h3 class="panel-title">News of the day</h3>
      </div>
      <div class="panel-body">
        <p>
          <a href="#">
            <img class="img-responsive" src="<?php echo e(asset('storage/9b21db7d79b206fd51da78b271fa5859.jpg')); ?>" alt="">
          </a>
        </p>
      </div>
    </div>
  </div>