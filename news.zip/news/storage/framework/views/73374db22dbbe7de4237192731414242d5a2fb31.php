<?php $__env->startSection('content'); ?>
<section class="container" style="margin-top:85px;">
	<div class="row">
		<?php echo $__env->make('admin/left-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div class="col-sm-9">
			<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<p><?php echo e($error); ?></p>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<p class="alert alert-warning"><?php echo e(session('success')); ?></p>
			<?php endif; ?>
			<h3 class="border-bottom" style="margin-bottom:20px;">Add News <a href="<?php echo e(url('admin')); ?>" class="pull-right btn btn-success btn-xs">
			<span class="glyphicon glyphicon-arrow-left"></span> News List</a></h3>
			<table class="table table-bordered display table-hover" id="dataTable">
				<form action="<?php echo e(url('admin/store-news')); ?>" method="post" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<tr>
						<th>Category</th>
						<td>
							<select name="_category" class="form-control">
								<option value="">--- Select Category ---</option>
								<?php if(count($categories)>0): ?>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($c->cat_id); ?>"><?php echo e($c->cat_title); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<option></option>
							</select>
						</td>
					</tr>
					<tr>
						<th>Title</th>
						<td><input type="text" class="form-control" placeholder="Title" name="_title" /></td>
					</tr>
					<tr>
						<th>Description</th>
						<td>
							<textarea class="form-control" id="editor" name="_desc" placeholder="Description" rows="15"></textarea>
						</td>
					</tr>
					<tr>
						<th>Image</th>
						<td><input type="file" name="img"></td>
					</tr>
					<tr>
						<td colspan="2">
							<input type="submit" value="Add Data" class="btn btn-danger" />
						</td>
					</tr>
				</form>
			</table>
		</div>
	</div>
</section>
<script type="text/javascript" src="<?php echo e(asset('lib/ckeditor/ckeditor.js')); ?>"></script>
<script type="text/javascript">
	CKEDITOR.replace('editor');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>